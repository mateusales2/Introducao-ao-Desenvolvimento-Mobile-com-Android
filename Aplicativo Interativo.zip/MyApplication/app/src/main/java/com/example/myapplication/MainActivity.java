package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button rollbutton = findViewById(R.id.rollbutton);
        final ImageView image_leftdice = findViewById(R.id.image_leftdice);
        final ImageView image_rightdice = findViewById(R.id.image_rightdice);
        final int [] diceeArray =

                {
                        R.drawable.dice1,
                        R.drawable.dice2,
                        R.drawable.dice3,
                        R.drawable.dice4,
                        R.drawable.dice5,
                        R.drawable.dice6
                };

        rollbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random numberRandom = new Random();
                int number = numberRandom.nextInt(6);
                image_leftdice.setImageResource(diceeArray[number]);
                number = numberRandom.nextInt(6);
                image_rightdice.setImageResource(diceeArray[number]);

            }
        });
    }
}